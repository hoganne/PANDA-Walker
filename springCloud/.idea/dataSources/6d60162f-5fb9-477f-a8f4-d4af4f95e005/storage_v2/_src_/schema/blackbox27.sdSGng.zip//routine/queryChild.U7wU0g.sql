create
    definer = root@`%` function queryChild(parentId int) returns varchar(4000)
BEGIN
DECLARE sTemp VARCHAR(4000);
DECLARE sTempChd VARCHAR(4000);
 
SET sTemp = '$';
SET sTempChd = cast(parentId as char);
 
WHILE sTempChd is not NULL DO
SET sTemp = CONCAT(sTemp,',',sTempChd);
SELECT group_concat(id) INTO sTempChd FROM struction where FIND_IN_SET(parent_id,sTempChd)>0;
END WHILE;
return sTemp;
END;

