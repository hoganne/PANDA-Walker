create
    definer = root@`%` function _nextval11(name varchar(50)) returns int
BEGIN
DECLARE _cur BIGINT;
DECLARE _maxvalue BIGINT;
DECLARE _increment BIGINT;
set _increment = (select increment_val from task_sequence where seq_name = name);
set _maxvalue = (select maxval from task_sequence where seq_name = name);
set _cur = (select current_val from task_sequence where seq_name = name);
update task_sequence
set current_val = _cur + increment_val 
where seq_name = name;
if(_cur + _increment >= _maxvalue) then 
update task_sequence 
set current_val = minval
where seq_name = name;
end if;
return _cur;
end;

